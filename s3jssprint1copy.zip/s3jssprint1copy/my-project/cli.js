const axios = require('axios');

// Function to generate a user token based on username
function generateUserToken(username) {
  axios.post('http://localhost:3000/submit', { username })
    .then(response => {
      if (response.data.success) {
        console.log('User token generated successfully:', response.data.token);
      } else {
        console.log('Failed to generate user token.');
      }
    })
    .catch(error => {
      console.error('An error occurred:', error.message);
    });
}

// Example usage
const username = 'exampleUser';
generateUserToken(username);

