const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.post('/submit', (req, res) => {
  const { username, email } = req.body;

  // Save the username and email to a file
  fs.appendFile('users.txt', `${username}, ${email}\n`, (err) => {
    if (err) {
      console.error(err);
      res.json({ success: false });
    } else {
      res.json({ success: true });
    }
  });
});

app.get('/users.html', (req, res) => {
  // Read the user data from the file
  fs.readFile('users.txt', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.json([]);
    } else {
      const users = data.split('\n').map(line => {
        const [username, email] = line.split(', ');
        return { username, email };
      });
      res.json(users);
    }
  });
});

// Add the delete route
app.post('/delete', (req, res) => {
  const { username } = req.body;

  // Read the user data from the file
  fs.readFile('users.txt', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.json({ success: false });
    } else {
      const users = data.split('\n').map(line => {
        const [existingUsername, email] = line.split(', ');
        return { username: existingUsername, email };
      });

      // Find and remove the user with the specified username
      const updatedUsers = users.filter(user => user.username !== username);

      // Write the updated user list back to the file
      fs.writeFile('users.txt', updatedUsers.map(user => `${user.username}, ${user.email}`).join('\n'), (err) => {
        if (err) {
          console.error(err);
          res.json({ success: false });
        } else {
          res.json({ success: true });
        }
      });
    }
  });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
